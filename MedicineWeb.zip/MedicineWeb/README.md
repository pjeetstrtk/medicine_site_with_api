# Medicine directory — web front end for MedicineApi

Plain HTML, CSS and JavaScript. No build step, no packages.

## Run

1. Start the API (`dotnet run` in the MedicineApi project; it listens on http://localhost:5080).
2. Open `index.html` in a browser (double-click works), or serve the folder:
   `python -m http.server 8080` then visit http://localhost:8080
3. If your API runs on another address, click **Change API address** at the bottom of the left menu.

The API already allows cross-origin requests, so no extra setup is needed.

## What it does

- Browse, search and page through medicines, generics, manufacturers, drug classes, indications and dosage forms.
- Filter medicines by type and dosage form. Use "Show brands…" / "Show generics…" in a detail panel to jump to related records.
- Click any row for details. Generic descriptions are shown as formatted text (the stored HTML is cleaned before display).
- New / Edit open a side panel. Dosage form, generic, manufacturer, drug class and indication are picked by typing and choosing a suggestion.
- Delete asks for confirmation and shows the API's message if the record is still in use.

## Files

| File | Purpose |
|---|---|
| `index.html` | Page layout and dialogs |
| `css/style.css` | All styling |
| `js/config.js` | Columns, form fields and filters for each data set |
| `js/api.js` | Fetch wrapper and error messages |
| `js/app.js` | List, detail panel, forms, delete |

Fonts (Bricolage Grotesque, Figtree) load from Google Fonts; without internet the system font is used.
