/*
 * Describes each API resource once: list columns, form fields, filters, detail facts.
 * Field keys match the JSON that MedicineApi sends and accepts (camelCase).
 */
(function () {
  'use strict';

  const FORMS = [['allopathic', 'Allopathic'], ['herbal', 'Herbal']];

  window.RESOURCES = {
    medicines: {
      label: 'Medicines', noun: 'medicine', path: 'medicines',
      idKey: 'brandId', createIdKey: 'brandId', nameKey: 'brandName',
      searchHint: 'Search brand names',
      columns: [
        { key: 'brandName', label: 'Brand', type: 'brand' },
        { key: 'strength', label: 'Strength' },
        { key: 'dosageFormName', label: 'Form' },
        { key: 'genericName', label: 'Generic', go: { res: 'generics', id: 'genericId' } },
        { key: 'manufacturerName', label: 'Manufacturer', go: { res: 'manufacturers', id: 'manufacturerId' } },
        { key: 'packageContainer', label: 'Price', type: 'price' }
      ],
      filters: [
        { key: 'type', label: 'Type', plural: 'types', options: FORMS },
        { key: 'dosageFormId', label: 'Dosage form', plural: 'dosage forms', from: 'dosageForms' }
      ],
      fields: [
        { key: 'brandName', label: 'Brand name', type: 'text', required: true, max: 100 },
        { key: 'type', label: 'Type', type: 'select', options: FORMS, required: true },
        { key: 'strength', label: 'Strength', type: 'text', max: 100, help: 'For example 500 mg or 10 mg/5 ml.' },
        { key: 'dosageFormId', label: 'Dosage form', type: 'lookup', res: 'dosageForms', nameKey: 'dosageFormName', required: true },
        { key: 'genericId', label: 'Generic', type: 'lookup', res: 'generics', nameKey: 'genericName' },
        { key: 'manufacturerId', label: 'Manufacturer', type: 'lookup', res: 'manufacturers', nameKey: 'manufacturerName', required: true },
        { key: 'packageContainer', label: 'Price and container', type: 'textarea', max: 500 },
        { key: 'packageSize', label: 'Pack size', type: 'text', max: 200 },
        { key: 'slug', label: 'Slug', type: 'text', max: 120, help: 'Leave blank to create it from the brand name.' }
      ],
      facts: [
        ['Type', 'type'], ['Strength', 'strength'], ['Dosage form', 'dosageFormName'],
        ['Generic', 'genericName'], ['Manufacturer', 'manufacturerName'],
        ['Price', 'packageContainer'], ['Pack size', 'packageSize'], ['Slug', 'slug']
      ],
      related: [
        { kind: 'open', label: 'Open generic', res: 'generics', idKey: 'genericId' },
        { kind: 'open', label: 'Open manufacturer', res: 'manufacturers', idKey: 'manufacturerId' }
      ]
    },

    generics: {
      label: 'Generics', noun: 'generic', path: 'generics',
      idKey: 'id', createIdKey: 'id', nameKey: 'name',
      searchHint: 'Search generic names',
      columns: [
        { key: 'name', label: 'Generic', type: 'name' },
        { key: 'drugClassName', label: 'Drug class', go: { res: 'drugClasses', id: 'drugClassId' } },
        { key: 'indicationName', label: 'Indication', go: { res: 'indications', id: 'indicationId' } }
      ],
      fields: [
        { key: 'name', label: 'Generic name', type: 'text', required: true, max: 150 },
        { key: 'drugClassId', label: 'Drug class', type: 'lookup', res: 'drugClasses', nameKey: 'drugClassName' },
        { key: 'indicationId', label: 'Indication', type: 'lookup', res: 'indications', nameKey: 'indicationName' },
        { key: 'monographLink', label: 'Monograph link', type: 'text', max: 500 },
        { key: 'slug', label: 'Slug', type: 'text', max: 150, help: 'Leave blank to create it from the name.' },
        { key: 'descriptionsCount', label: 'Description sections filled', type: 'number', max: 255 },
        { key: 'indicationDescription', label: 'Indications', type: 'textarea', group: true },
        { key: 'therapeuticClassDescription', label: 'Therapeutic class', type: 'textarea', group: true },
        { key: 'pharmacologyDescription', label: 'Pharmacology', type: 'textarea', group: true },
        { key: 'dosageDescription', label: 'Dosage', type: 'textarea', group: true },
        { key: 'administrationDescription', label: 'Administration', type: 'textarea', group: true },
        { key: 'interactionDescription', label: 'Interactions', type: 'textarea', group: true },
        { key: 'contraindicationsDescription', label: 'Contraindications', type: 'textarea', group: true },
        { key: 'sideEffectsDescription', label: 'Side effects', type: 'textarea', group: true },
        { key: 'pregnancyLactationDescription', label: 'Pregnancy and lactation', type: 'textarea', group: true },
        { key: 'precautionsDescription', label: 'Precautions', type: 'textarea', group: true },
        { key: 'pediatricUsageDescription', label: 'Pediatric use', type: 'textarea', group: true },
        { key: 'overdoseEffectsDescription', label: 'Overdose', type: 'textarea', group: true },
        { key: 'durationOfTreatmentDescription', label: 'Duration of treatment', type: 'textarea', group: true },
        { key: 'reconstitutionDescription', label: 'Reconstitution', type: 'textarea', group: true },
        { key: 'storageConditionsDescription', label: 'Storage conditions', type: 'textarea', group: true }
      ],
      facts: [
        ['Drug class', 'drugClassName'], ['Indication', 'indicationName'],
        ['Monograph', 'monographLink'], ['Slug', 'slug']
      ],
      related: [
        { kind: 'browse', label: 'Show brands with this generic', res: 'medicines', filterKey: 'genericId', filterLabel: 'Generic' }
      ],
      deleteNote: 'Brands that use it stay, but lose their generic.',
      groupTitle: 'Descriptions (HTML)'
    },

    manufacturers: {
      label: 'Manufacturers', noun: 'manufacturer', path: 'manufacturers',
      idKey: 'id', createIdKey: 'id', nameKey: 'name',
      searchHint: 'Search manufacturers',
      columns: [
        { key: 'name', label: 'Manufacturer', type: 'name' },
        { key: 'genericsCount', label: 'Generics', type: 'count' },
        { key: 'brandNamesCount', label: 'Brands', type: 'count' }
      ],
      fields: [
        { key: 'name', label: 'Name', type: 'text', required: true, max: 100 },
        { key: 'genericsCount', label: 'Generics count', type: 'number' },
        { key: 'brandNamesCount', label: 'Brands count', type: 'number' },
        { key: 'slug', label: 'Slug', type: 'text', max: 120, help: 'Leave blank to create it from the name.' }
      ],
      facts: [['Generics', 'genericsCount'], ['Brands', 'brandNamesCount'], ['Slug', 'slug']],
      related: [
        { kind: 'browse', label: 'Show brands by this manufacturer', res: 'medicines', filterKey: 'manufacturerId', filterLabel: 'Manufacturer' }
      ],
      deleteNote: 'A manufacturer that still has brands cannot be deleted.'
    },

    drugClasses: {
      label: 'Drug classes', noun: 'drug class', path: 'drug-classes',
      idKey: 'id', createIdKey: 'id', nameKey: 'name',
      searchHint: 'Search drug classes',
      columns: [
        { key: 'name', label: 'Drug class', type: 'name' },
        { key: 'genericsCount', label: 'Generics', type: 'count' }
      ],
      fields: [
        { key: 'name', label: 'Name', type: 'text', required: true, max: 100 },
        { key: 'genericsCount', label: 'Generics count', type: 'number' },
        { key: 'slug', label: 'Slug', type: 'text', max: 120, help: 'Leave blank to create it from the name.' }
      ],
      facts: [['Generics', 'genericsCount'], ['Slug', 'slug']],
      related: [
        { kind: 'browse', label: 'Show generics in this class', res: 'generics', filterKey: 'drugClassId', filterLabel: 'Class' }
      ],
      deleteNote: 'Generics in this class stay, but lose their class.'
    },

    indications: {
      label: 'Indications', noun: 'indication', path: 'indications',
      idKey: 'id', createIdKey: 'id', nameKey: 'name',
      searchHint: 'Search indications',
      columns: [
        { key: 'name', label: 'Indication', type: 'name' },
        { key: 'genericsCount', label: 'Generics', type: 'count' }
      ],
      fields: [
        { key: 'name', label: 'Name', type: 'text', required: true, max: 150 },
        { key: 'genericsCount', label: 'Generics count', type: 'number' },
        { key: 'slug', label: 'Slug', type: 'text', max: 160, help: 'Leave blank to create it from the name.' }
      ],
      facts: [['Generics', 'genericsCount'], ['Slug', 'slug']],
      related: [
        { kind: 'browse', label: 'Show generics for this indication', res: 'generics', filterKey: 'indicationId', filterLabel: 'Indication' }
      ],
      deleteNote: 'Generics with this indication stay, but lose it.'
    },

    dosageForms: {
      label: 'Dosage forms', noun: 'dosage form', path: 'dosage-forms',
      idKey: 'id', createIdKey: 'id', nameKey: 'name',
      searchHint: 'Search dosage forms',
      columns: [
        { key: 'name', label: 'Dosage form', type: 'name' },
        { key: 'brandNamesCount', label: 'Brands', type: 'count' }
      ],
      fields: [
        { key: 'name', label: 'Name', type: 'text', required: true, max: 60 },
        { key: 'brandNamesCount', label: 'Brands count', type: 'number' },
        { key: 'slug', label: 'Slug', type: 'text', max: 70, help: 'Leave blank to create it from the name.' }
      ],
      facts: [['Brands', 'brandNamesCount'], ['Slug', 'slug']],
      related: [
        { kind: 'browse', label: 'Show brands in this form', res: 'medicines', filterKey: 'dosageFormId', filterLabel: 'Form' }
      ],
      deleteNote: 'A dosage form that still has brands cannot be deleted.'
    }
  };
})();
