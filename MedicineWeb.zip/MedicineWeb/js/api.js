/* Tiny fetch wrapper for MedicineApi. Classic script (works from file://). */
(function () {
  'use strict';

  const KEY = 'medicineApiBase';
  const DEFAULT_BASE = 'http://localhost:5080';

  function getBase() {
    try { return localStorage.getItem(KEY) || DEFAULT_BASE; } catch { return DEFAULT_BASE; }
  }

  function setBase(value) {
    try { localStorage.setItem(KEY, value.replace(/\/+$/, '')); } catch { /* storage unavailable */ }
  }

  class ApiError extends Error {
    constructor(message, status) {
      super(message);
      this.status = status;
    }
  }

  function describe(problem, res) {
    if (problem && problem.errors) {
      const messages = Object.values(problem.errors).flat();
      if (messages.length) return messages.join(' ');
    }
    if (problem && problem.title) return problem.title;
    return `The request failed (HTTP ${res.status}).`;
  }

  async function request(method, path, body) {
    let res;
    try {
      res = await fetch(`${getBase()}/api/${path}`, {
        method,
        headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
        body: body !== undefined ? JSON.stringify(body) : undefined
      });
    } catch {
      throw new ApiError(
        `Can't reach the API at ${getBase()}. Check that MedicineApi is running and the address is correct.`, 0);
    }
    if (res.status === 204) return null;

    const text = await res.text();
    let data = null;
    if (text) { try { data = JSON.parse(text); } catch { /* not JSON */ } }
    if (!res.ok) throw new ApiError(describe(data, res), res.status);
    return data;
  }

  function qs(params) {
    const u = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== '' && v != null) u.set(k, v);
    }
    const s = u.toString();
    return s ? `?${s}` : '';
  }

  window.Api = {
    getBase, setBase, qs,
    get: (p) => request('GET', p),
    post: (p, b) => request('POST', p, b),
    put: (p, b) => request('PUT', p, b),
    del: (p) => request('DELETE', p)
  };
})();
