/* Medicine directory — browse, search, create, edit and delete via MedicineApi. */
(function () {
  'use strict';

  const R = window.RESOURCES;
  const $ = (sel, root = document) => root.querySelector(sel);
  const fmt = new Intl.NumberFormat('en-US');
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

  const state = { res: 'medicines', page: 1, pageSize: 25, search: '', filters: {}, chips: {}, data: null };
  const optionCache = {};
  let loadToken = 0;
  let searchTimer = 0;
  let ignoreHash = false;

  // ---------- small DOM helper ----------
  function el(tag, props, ...kids) {
    const n = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v == null || v === false) continue;
        if (k === 'class') n.className = v;
        else if (k === 'text') n.textContent = v;
        else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
        else if (v === true) n.setAttribute(k, '');
        else n.setAttribute(k, v);
      }
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return n;
  }

  // ---------- toasts ----------
  function toast(message, kind = 'ok') {
    const t = el('div', { class: `toast ${kind}`, role: kind === 'error' ? 'alert' : 'status', text: message });
    $('#toasts').append(t);
    setTimeout(() => t.remove(), kind === 'error' ? 8000 : 3500);
  }

  // ---------- price text like "Unit Price: ৳ 1.00,(100's pack: ৳ 100.00)," ----------
  function priceLines(text) {
    if (!text) return [];
    return text
      .split(/,,|,(?=\d+\s?(?:ml|gm|mg|l|g|kg)\b)/)
      .map((s) => s.replace(/,\s*$/, '').trim())
      .filter(Boolean);
  }

  function priceCell(text) {
    const first = priceLines(text)[0];
    if (!first) return el('span', { class: 'muted', text: '—' });
    const m = first.match(/৳\s*[\d,]*\d(?:\.\d+)?/);
    if (!m) return first;
    const label = first.split(':')[0];
    const isUnit = /unit price/i.test(label);
    return el('span', { class: 'price' }, m[0], isUnit ? null : el('small', { class: 'muted', text: ` ${label}` }));
  }

  // ---------- safe rendering of the HTML stored in description columns ----------
  const ALLOWED = new Set(['P', 'BR', 'UL', 'OL', 'LI', 'STRONG', 'B', 'EM', 'I', 'U', 'SUP', 'SUB',
    'TABLE', 'THEAD', 'TBODY', 'TR', 'TD', 'TH', 'H3', 'H4', 'H5', 'A', 'DIV', 'SPAN']);

  function sanitize(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    doc.querySelectorAll('script, style, iframe, object, embed, link, meta, form, input, button').forEach((n) => n.remove());
    // The source markup holds a hidden "short" copy next to the full text; keep only the full one.
    doc.querySelectorAll('.min-str-toggle').forEach((n) => n.remove());
    doc.querySelectorAll('.min-str').forEach((n) => {
      if (n.parentElement && n.parentElement.querySelector('.full-str')) n.remove();
    });
    (function clean(node) {
      for (const ch of [...node.childNodes]) {
        if (ch.nodeType === 3) continue;
        if (ch.nodeType !== 1) { ch.remove(); continue; }
        clean(ch);
        const tag = ch.tagName;
        if (!ALLOWED.has(tag)) { ch.replaceWith(...ch.childNodes); continue; }
        for (const a of [...ch.attributes]) {
          if (!(tag === 'A' && a.name === 'href')) ch.removeAttribute(a.name);
        }
        if (tag === 'A') {
          const href = ch.getAttribute('href') || '';
          if (/^https?:\/\//i.test(href)) { ch.target = '_blank'; ch.rel = 'noopener noreferrer'; }
          else ch.removeAttribute('href');
        }
      }
    })(doc.body);
    return doc.body.innerHTML;
  }

  // ---------- connection indicator ----------
  function setConnected(ok) {
    let host = Api.getBase();
    try { host = new URL(host).host; } catch { /* keep raw */ }
    $('#connDot').className = `dot ${ok ? 'on' : 'off'}`;
    $('#connText').textContent = ok ? `Connected to ${host}` : `Can't reach ${host}`;
  }

  // ---------- navigation / header / filters ----------
  function renderNav() {
    $('#nav').replaceChildren(...Object.entries(R).map(([key, r]) =>
      el('a', { href: `#${key}`, 'aria-current': key === state.res ? 'page' : null, text: r.label })));
  }

  function renderHead() {
    const r = R[state.res];
    $('#title').textContent = r.label;
    $('#subtitle').textContent = '';
    $('#newBtn').textContent = `New ${r.noun}`;
    const search = $('#search');
    search.value = state.search;
    search.placeholder = r.searchHint;
    search.setAttribute('aria-label', r.searchHint);
    document.title = `${r.label} · Medicine directory`;
  }

  async function loadOptions(resKey) {
    if (!optionCache[resKey]) {
      const data = await Api.get(`${R[resKey].path}?pageSize=200`);
      optionCache[resKey] = data.items.map((i) => [String(i.id), i.name]);
    }
    return optionCache[resKey];
  }

  function renderFilters() {
    const box = $('#filters');
    box.replaceChildren();
    for (const f of R[state.res].filters || []) {
      const sel = el('select', {
        'aria-label': f.label,
        onchange: () => {
          if (sel.value) { state.filters[f.key] = sel.value; delete state.chips[f.key]; }
          else delete state.filters[f.key];
          state.page = 1;
          renderChips();
          load();
        }
      }, el('option', { value: '', text: `All ${f.plural}` }));
      box.append(sel);
      const fill = (opts) => {
        opts.forEach(([v, l]) => sel.append(el('option', { value: v, text: l })));
        if (state.filters[f.key]) sel.value = state.filters[f.key];
      };
      if (f.options) fill(f.options);
      else loadOptions(f.from).then(fill).catch(() => { /* list still works without the filter options */ });
    }
  }

  function renderChips() {
    const box = $('#chips');
    box.replaceChildren();
    const controlKeys = new Set((R[state.res].filters || []).map((f) => f.key));
    for (const key of Object.keys(state.filters)) {
      if (controlKeys.has(key)) continue;
      box.append(el('span', { class: 'chip' },
        state.chips[key] || key,
        el('button', {
          type: 'button', 'aria-label': 'Remove filter', text: '×',
          onclick: () => { delete state.filters[key]; delete state.chips[key]; state.page = 1; renderChips(); load(); }
        })));
    }
    box.hidden = !box.children.length;
  }

  function switchResource(key, filters = {}, chips = {}) {
    if (!R[key]) key = 'medicines';
    state.res = key;
    state.page = 1;
    state.search = '';
    state.filters = { ...filters };
    state.chips = { ...chips };
    state.data = null;
    renderNav();
    renderHead();
    renderFilters();
    renderChips();
    buildThead();
    $('#table tbody').replaceChildren(el('tr', null, el('td', { colspan: R[key].columns.length + 1, class: 'empty', text: 'Loading…' })));
    load();
  }

  function go(key, filters, chips) {
    ignoreHash = location.hash !== `#${key}`;
    location.hash = key;
    switchResource(key, filters, chips);
  }

  // ---------- list ----------
  function buildThead() {
    const r = R[state.res];
    $('#table thead').replaceChildren(el('tr', null,
      ...r.columns.map((c) => el('th', { scope: 'col', class: c.type === 'count' ? 'num' : null, text: c.label })),
      el('th', { scope: 'col', class: 'actions-col' }, el('span', { class: 'sr-only', text: 'Actions' }))));
    $('#table caption').textContent = r.label;
  }

  async function load() {
    const token = ++loadToken;
    const r = R[state.res];
    $('#tableWrap').classList.add('busy');
    try {
      const data = await Api.get(r.path + Api.qs({
        page: state.page, pageSize: state.pageSize, search: state.search, ...state.filters
      }));
      if (token !== loadToken) return;
      state.data = data;
      setConnected(true);
      renderTable();
    } catch (e) {
      if (token !== loadToken) return;
      setConnected(e.status !== 0);
      renderError(e);
    } finally {
      if (token === loadToken) $('#tableWrap').classList.remove('busy');
    }
  }

  function emptyMessage() {
    const r = R[state.res];
    if (state.search) return `Nothing matches “${state.search}”. Try a shorter search or clear the filters.`;
    if (Object.keys(state.filters).length) return 'Nothing matches these filters. Remove a filter to see more.';
    return `No ${r.label.toLowerCase()} yet. Choose “New ${r.noun}” to add the first one.`;
  }

  function renderError(e) {
    const r = R[state.res];
    $('#subtitle').textContent = '';
    $('#table tbody').replaceChildren(el('tr', null,
      el('td', { colspan: r.columns.length + 1, class: 'empty' },
        el('p', { class: 'error-text', role: 'alert', text: e.message }),
        el('button', { type: 'button', class: 'ghost', text: 'Try again', onclick: () => load() }))));
    $('#range').textContent = '';
    $('#pageNo').textContent = '';
    $('#prev').disabled = true;
    $('#next').disabled = true;
  }

  function renderTable() {
    const r = R[state.res];
    const { items, totalCount, pageSize } = state.data;

    if (!items.length && state.page > 1 && totalCount > 0) {
      state.page = Math.max(1, Math.ceil(totalCount / pageSize));
      load();
      return;
    }

    const tb = $('#table tbody');
    tb.replaceChildren();
    if (!items.length) {
      tb.append(el('tr', null, el('td', { colspan: r.columns.length + 1, class: 'empty', text: emptyMessage() })));
    }
    for (const row of items) tb.append(rowEl(r, row));

    const filtered = state.search || Object.keys(state.filters).length;
    const noun = totalCount === 1 ? r.noun : r.label.toLowerCase();
    $('#subtitle').textContent = `${fmt.format(totalCount)} ${filtered ? 'matching ' : ''}${noun}`;
    renderPager();
  }

  function rowEl(r, row) {
    const id = row[r.idKey];
    const tr = el('tr', { class: 'row', onclick: () => openDetail(state.res, id) });
    r.columns.forEach((c) => tr.append(el('td', { class: c.type === 'count' ? 'num' : null, 'data-label': c.label }, cell(r, c, row))));
    tr.append(el('td', { class: 'actions-col' },
      el('button', { type: 'button', class: 'ghost sm', text: 'Edit', 'aria-label': `Edit ${row[r.nameKey]}`, onclick: (e) => { e.stopPropagation(); openForm(state.res, id); } }),
      el('button', { type: 'button', class: 'ghost sm danger-text', text: 'Delete', 'aria-label': `Delete ${row[r.nameKey]}`, onclick: (e) => { e.stopPropagation(); askDelete(state.res, row); } })));
    return tr;
  }

  function cell(r, c, row) {
    const v = row[c.key];
    const id = row[r.idKey];
    if (c.type === 'price') return priceCell(v);
    if (c.type === 'brand') {
      return el('span', { class: 'brand-cell' },
        el('span', { class: 'cap', 'data-type': row.type, title: cap(row.type || '') }),
        el('button', { type: 'button', class: 'name-btn', text: v, onclick: (e) => { e.stopPropagation(); openDetail(state.res, id); } }));
    }
    if (c.type === 'name') {
      return el('button', { type: 'button', class: 'name-btn', text: v, onclick: (e) => { e.stopPropagation(); openDetail(state.res, id); } });
    }
    if (v == null || v === '') return el('span', { class: 'muted', text: '—' });
    if (c.type === 'count') return fmt.format(v);
    if (c.go && row[c.go.id] != null) {
      return el('button', { type: 'button', class: 'link-btn', text: v, onclick: (e) => { e.stopPropagation(); openDetail(c.go.res, row[c.go.id]); } });
    }
    return String(v);
  }

  function renderPager() {
    const { totalCount, page, pageSize, totalPages } = state.data;
    const from = totalCount ? (page - 1) * pageSize + 1 : 0;
    const to = Math.min(page * pageSize, totalCount);
    $('#range').textContent = totalCount ? `${fmt.format(from)}–${fmt.format(to)} of ${fmt.format(totalCount)}` : 'No results';
    $('#pageNo').textContent = totalPages ? `Page ${fmt.format(page)} of ${fmt.format(totalPages)}` : '';
    $('#prev').disabled = page <= 1;
    $('#next').disabled = page >= totalPages;
  }

  // ---------- drawer ----------
  const drawer = $('#drawer');

  function showDrawer(title, ...nodes) {
    $('#drawerTitle').textContent = title;
    $('#drawerBody').replaceChildren(...nodes);
    $('#drawerBody').scrollTop = 0;
    if (!drawer.open) drawer.showModal();
  }

  function factValue(key, v) {
    if (v == null || v === '') return el('span', { class: 'muted', text: '—' });
    if (key === 'type') return cap(String(v));
    if (key === 'packageContainer') {
      return el('span', { class: 'lines' }, ...priceLines(v).map((l) => el('span', { text: l })));
    }
    if (key === 'monographLink' && /^https?:\/\//i.test(v)) {
      return el('a', { href: v, target: '_blank', rel: 'noopener noreferrer', text: 'Open prescribing information' });
    }
    return typeof v === 'number' ? fmt.format(v) : String(v);
  }

  async function openDetail(resKey, id) {
    const r = R[resKey];
    showDrawer(cap(r.noun), el('p', { class: 'muted', text: 'Loading…' }));
    try {
      renderDetail(resKey, await Api.get(`${r.path}/${id}`));
    } catch (e) {
      drawer.close();
      toast(e.message, 'error');
    }
  }

  function renderDetail(resKey, row) {
    const r = R[resKey];
    const name = row[r.nameKey];
    const nodes = [];

    if (resKey === 'medicines') {
      nodes.push(el('p', { class: 'type-line' }, el('span', { class: 'cap big', 'data-type': row.type }), cap(row.type)));
    }

    const dl = el('dl', { class: 'facts' });
    for (const [label, key] of r.facts) dl.append(el('dt', { text: label }), el('dd', null, factValue(key, row[key])));
    nodes.push(dl);

    const sections = r.fields.filter((f) => f.group);
    if (sections.length) {
      const box = el('div', { class: 'sections' });
      let shown = 0;
      for (const f of sections) {
        if (!row[f.key]) continue;
        const body = el('div', { class: 'prose' });
        body.innerHTML = sanitize(row[f.key]);
        box.append(el('details', { open: shown === 0 }, el('summary', { text: f.label }), body));
        shown++;
      }
      if (!shown) box.append(el('p', { class: 'muted', text: 'No description sections on record.' }));
      nodes.push(box);
    }

    const links = [];
    for (const rel of r.related || []) {
      if (rel.kind === 'open') {
        if (row[rel.idKey] == null) continue;
        links.push(el('button', { type: 'button', class: 'ghost', text: rel.label, onclick: () => openDetail(rel.res, row[rel.idKey]) }));
      } else {
        links.push(el('button', {
          type: 'button', class: 'ghost', text: rel.label,
          onclick: () => {
            drawer.close();
            go(rel.res, { [rel.filterKey]: String(row[r.idKey]) }, { [rel.filterKey]: `${rel.filterLabel}: ${name}` });
          }
        }));
      }
    }
    if (links.length) nodes.push(el('div', { class: 'link-row' }, links));

    nodes.push(el('div', { class: 'drawer-foot' },
      el('button', { type: 'button', class: 'danger-outline', text: 'Delete', onclick: () => askDelete(resKey, row) }),
      el('button', { type: 'button', class: 'primary', text: 'Edit', onclick: () => openForm(resKey, row[r.idKey]) })));

    showDrawer(name, ...nodes);
  }

  // ---------- create / edit form ----------
  function lookupControl(f, row, id) {
    const listId = `dl_${f.key}`;
    const input = el('input', {
      id, name: f.key, type: 'text', list: listId, autocomplete: 'off',
      placeholder: 'Type to search…', required: f.required || null
    });
    const dl = el('datalist', { id: listId });
    const current = row ? row[f.key] : null;
    if (current != null) {
      input.value = `${row[f.nameKey]} #${current}`;
      input.dataset.id = current;
    }
    const sync = () => {
      const m = input.value.match(/#(\d+)\s*$/);
      input.dataset.id = m ? m[1] : '';
      input.setCustomValidity(input.value.trim() && !m ? 'Choose one of the suggestions.' : '');
    };
    let timer = 0;
    input.addEventListener('input', () => {
      sync();
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const term = input.value.replace(/\s*#\d+\s*$/, '').trim();
        if (!term) return;
        try {
          const res = await Api.get(R[f.res].path + Api.qs({ search: term, pageSize: 15 }));
          dl.replaceChildren(...res.items.map((i) => el('option', { value: `${i.name} #${i.id}` })));
        } catch { /* suggestions are optional */ }
      }, 250);
    });
    return [input, dl];
  }

  function fieldEl(f, row) {
    const id = `f_${f.key}`;
    let control;
    const value = row && row[f.key] != null ? row[f.key] : '';

    if (f.type === 'lookup') {
      control = lookupControl(f, row, id);
    } else if (f.type === 'select') {
      const sel = el('select', { id, name: f.key, required: f.required || null },
        ...f.options.map(([v, l]) => el('option', { value: v, text: l })));
      if (value) sel.value = value;
      control = sel;
    } else if (f.type === 'textarea') {
      const ta = el('textarea', { id, name: f.key, rows: f.group ? 7 : 3, maxlength: f.max || null });
      ta.value = value;
      control = ta;
    } else if (f.type === 'number') {
      control = el('input', { id, name: f.key, type: 'number', min: 0, step: 1, max: f.max || null, value });
    } else {
      control = el('input', { id, name: f.key, type: 'text', maxlength: f.max || null, required: f.required || null, value });
    }

    return el('div', { class: 'field' },
      el('label', { for: id, text: f.label }),
      control,
      f.help ? el('p', { class: 'help', text: f.help }) : null);
  }

  function buildForm(resKey, row) {
    const r = R[resKey];
    let fields = r.fields.slice();
    if (!row) {
      fields.unshift({ key: r.createIdKey, label: 'ID', type: 'number', help: 'Leave blank to use the next free ID.' });
    }
    const plain = fields.filter((f) => !f.group);
    const grouped = fields.filter((f) => f.group);

    const errorBox = el('p', { class: 'error-text', role: 'alert', hidden: true });
    const submit = el('button', { type: 'submit', class: 'primary', text: 'Save' });
    const form = el('form', { class: 'form' },
      ...plain.map((f) => fieldEl(f, row)),
      grouped.length
        ? el('details', { class: 'group' },
            el('summary', { text: r.groupTitle || 'More fields' }),
            ...grouped.map((f) => fieldEl(f, row)))
        : null,
      errorBox,
      el('div', { class: 'drawer-foot' },
        el('button', { type: 'button', class: 'ghost', text: 'Cancel', onclick: () => drawer.close() }),
        submit));

    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const body = {};
      for (const f of fields) {
        const c = form.elements[f.key];
        if (!c) continue;
        let v;
        if (f.type === 'lookup') v = c.dataset.id ? Number(c.dataset.id) : null;
        else if (f.type === 'number') v = c.value === '' ? null : Number(c.value);
        else {
          v = c.value.trim();
          if (v === '' && f.type !== 'select') v = null;
        }
        if (v === null && !row && f.key === r.createIdKey) continue;
        body[f.key] = v;
      }

      errorBox.hidden = true;
      submit.disabled = true;
      submit.textContent = 'Saving…';
      try {
        if (row) await Api.put(`${r.path}/${row[r.idKey]}`, body);
        else await Api.post(r.path, body);
        toast(`${cap(r.noun)} saved`);
        delete optionCache[resKey];
        drawer.close();
        load();
      } catch (e) {
        errorBox.textContent = e.message;
        errorBox.hidden = false;
        submit.disabled = false;
        submit.textContent = 'Save';
      }
    });
    return form;
  }

  async function openForm(resKey, id) {
    const r = R[resKey];
    if (id == null) {
      showDrawer(`New ${r.noun}`, buildForm(resKey, null));
      return;
    }
    showDrawer(`Edit ${r.noun}`, el('p', { class: 'muted', text: 'Loading…' }));
    try {
      const row = await Api.get(`${r.path}/${id}`);
      showDrawer(`Edit ${r.noun}`, buildForm(resKey, row));
    } catch (e) {
      drawer.close();
      toast(e.message, 'error');
    }
  }

  // ---------- delete ----------
  function confirmBox(title, message, okText) {
    return new Promise((resolve) => {
      const d = $('#confirm');
      $('#confirmTitle').textContent = title;
      $('#confirmMsg').textContent = message;
      $('#confirmOk').textContent = okText;
      d.returnValue = '';
      d.addEventListener('close', () => resolve(d.returnValue === 'ok'), { once: true });
      d.showModal();
    });
  }

  async function askDelete(resKey, row) {
    const r = R[resKey];
    const ok = await confirmBox(
      `Delete ${r.noun}?`,
      `“${row[r.nameKey]}” will be removed permanently.${r.deleteNote ? ' ' + r.deleteNote : ''}`,
      `Delete ${r.noun}`);
    if (!ok) return;
    try {
      await Api.del(`${r.path}/${row[r.idKey]}`);
      toast(`${cap(r.noun)} deleted`);
      delete optionCache[resKey];
      if (drawer.open) drawer.close();
      load();
    } catch (e) {
      toast(e.message, 'error');
    }
  }

  // ---------- wiring ----------
  $('#search').addEventListener('input', (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.search = e.target.value.trim(); state.page = 1; load(); }, 300);
  });
  $('#pageSize').addEventListener('change', (e) => { state.pageSize = Number(e.target.value); state.page = 1; load(); });
  $('#prev').addEventListener('click', () => { state.page = Math.max(1, state.page - 1); load(); });
  $('#next').addEventListener('click', () => { state.page += 1; load(); });
  $('#newBtn').addEventListener('click', () => openForm(state.res, null));
  $('#drawerClose').addEventListener('click', () => drawer.close());
  drawer.addEventListener('click', (e) => {
    if (e.target !== drawer) return;
    const b = drawer.getBoundingClientRect();
    if (e.clientX < b.left || e.clientX > b.right || e.clientY < b.top || e.clientY > b.bottom) drawer.close();
  });

  $('#apiBtn').addEventListener('click', () => {
    $('#apiInput').value = Api.getBase();
    $('#settings').showModal();
  });
  $('#settings').addEventListener('close', () => {
    if ($('#settings').returnValue !== 'save') return;
    const v = $('#apiInput').value.trim();
    if (!v) return;
    Api.setBase(v);
    Object.keys(optionCache).forEach((k) => delete optionCache[k]);
    setConnected(false);
    switchResource(state.res, state.filters, state.chips);
  });

  window.addEventListener('hashchange', () => {
    if (ignoreHash) { ignoreHash = false; return; }
    const key = location.hash.slice(1);
    if (key !== state.res) switchResource(key);
  });

  setConnected(false);
  $('#connText').textContent = 'Checking API…';
  switchResource(location.hash.slice(1) || 'medicines');
})();
