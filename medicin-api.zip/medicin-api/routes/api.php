<?php

use App\Http\Controllers\Api\ResourceController;
use App\Support\ResourceDefinitions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// URLs match the .NET MedicineApi exactly:  /api/medicines, /api/drug-classes, ...
foreach (ResourceDefinitions::PATHS as $path => $res) {
    Route::get("/$path", fn (Request $r) => app(ResourceController::class)->index($r, $res));
    Route::post("/$path", fn (Request $r) => app(ResourceController::class)->store($r, $res));
    Route::get("/$path/{id}", fn (Request $r, int $id) => app(ResourceController::class)->show($r, $res, $id))->whereNumber('id');
    Route::put("/$path/{id}", fn (Request $r, int $id) => app(ResourceController::class)->update($r, $res, $id))->whereNumber('id');
    Route::delete("/$path/{id}", fn (Request $r, int $id) => app(ResourceController::class)->destroy($r, $res, $id))->whereNumber('id');
}
