API routes are registered under /api/v1 when routes/api.php is loaded.
