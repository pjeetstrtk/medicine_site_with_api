<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Support\ResourceDefinitions;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

/**
 * One controller for all six resources. Speaks the same JSON contract as the
 * .NET MedicineApi so MedicineWeb works unchanged.
 */
class ResourceController extends Controller
{
    public function index(Request $request, string $res)
    {
        $d = $this->def($res);
        $page = max(1, (int) $request->query('page', 1));
        $size = min(200, max(1, (int) $request->query('pageSize', 20)));

        $q = ($d['base'])();

        $search = trim((string) $request->query('search', ''));
        if ($search !== '') {
            $like = '%' . addcslashes($search, '\\%_') . '%';
            $q->where(function ($w) use ($d, $like) {
                foreach ($d['search'] as $col) {
                    $w->orWhere($col, 'like', $like);
                }
            });
        }

        foreach ($d['filters'] as $key => $col) {
            $v = $request->query($key);
            if ($v !== null && $v !== '') {
                $q->where($col, $key === 'type' ? (string) $v : (int) $v);
            }
        }

        $total = (clone $q)->count();
        $items = $q->select($d['list'])
            ->orderBy($d['order'])
            ->orderBy($d['pk'])
            ->forPage($page, $size)
            ->get();

        return response()->json([
            'items'      => $items,
            'totalCount' => $total,
            'page'       => $page,
            'pageSize'   => $size,
            'totalPages' => (int) ceil($total / $size),
        ]);
    }

    public function show(Request $request, string $res, int $id)
    {
        $d = $this->def($res);
        $row = $this->find($d, $id);
        return $row ? response()->json($row) : $this->notFound($d);
    }

    public function store(Request $request, string $res)
    {
        $d = $this->def($res);
        $v = Validator::make($request->all(), $this->rules($d, false, null));
        if ($v->fails()) {
            return $this->invalid($v);
        }

        $data = $v->validated();
        $given = $data[$d['idKey']] ?? null;
        $id = $given !== null ? (int) $given : ((int) DB::table($d['table'])->max($d['pkCol']) + 1);

        $row = $this->toRow($d, $data);
        $row[$d['pkCol']] = $id;
        if (empty($row['slug'])) {
            $row['slug'] = $this->makeSlug($d, (string) ($data[$d['nameKey']] ?? ''), $id);
        }

        DB::table($d['table'])->insert($row);

        return response()->json($this->find($d, $id), 201);
    }

    public function update(Request $request, string $res, int $id)
    {
        $d = $this->def($res);
        $existing = $this->find($d, $id);
        if (!$existing) {
            return $this->notFound($d);
        }

        $v = Validator::make($request->all(), $this->rules($d, true, $id));
        if ($v->fails()) {
            return $this->invalid($v);
        }

        $data = $v->validated();
        $row = $this->toRow($d, $data);
        if (array_key_exists('slug', $row) && ($row['slug'] === null || $row['slug'] === '')) {
            $name = (string) ($data[$d['nameKey']] ?? $existing->{$d['nameKey']});
            $row['slug'] = $this->makeSlug($d, $name, $id);
        }
        if ($row) {
            DB::table($d['table'])->where($d['pkCol'], $id)->update($row);
        }

        return response()->noContent();
    }

    public function destroy(Request $request, string $res, int $id)
    {
        $d = $this->def($res);
        if (!$this->find($d, $id)) {
            return $this->notFound($d);
        }

        foreach ($d['dependents'] as [$table, $col]) {
            $n = DB::table($table)->where($col, $id)->count();
            if ($n > 0) {
                return response()->json([
                    'title' => "This {$d['noun']} is still used by $n brand" . ($n === 1 ? '' : 's') . ', so it cannot be deleted.',
                ], 409);
            }
        }

        DB::table($d['table'])->where($d['pkCol'], $id)->delete();

        return response()->noContent();
    }

    // ---------------------------------------------------------------- helpers

    private function def(string $res): array
    {
        $d = ResourceDefinitions::get($res);
        abort_if($d === null, 404);
        return $d;
    }

    private function find(array $d, int $id)
    {
        return ($d['base'])()
            ->select(array_merge($d['list'], $d['detail']))
            ->where($d['pk'], $id)
            ->first();
    }

    private function rules(array $d, bool $update, ?int $id): array
    {
        $rules = [];
        foreach ($d['fields'] as $key => [$col, $r]) {
            if (in_array($col, $d['unique'], true)) {
                $r[] = Rule::unique($d['table'], $col)->ignore($id, $d['pkCol']);
            }
            if ($update) {
                array_unshift($r, 'sometimes');
            }
            $rules[$key] = $r;
        }
        if (!$update) {
            $rules[$d['idKey']] = ['nullable', 'integer', 'min:1', Rule::unique($d['table'], $d['pkCol'])];
        }
        return $rules;
    }

    private function toRow(array $d, array $data): array
    {
        $row = [];
        foreach ($d['fields'] as $key => [$col]) {
            if (array_key_exists($key, $data)) {
                $row[$col] = $data[$key] === '' ? null : $data[$key];
            }
        }
        return $row;
    }

    private function makeSlug(array $d, string $name, int $id): string
    {
        $base = Str::slug($name);
        if ($base === '') {
            $base = Str::slug($d['noun']) . '-' . $id;
        } elseif (in_array('slug', $d['unique'], true)
            && DB::table($d['table'])->where('slug', $base)->where($d['pkCol'], '<>', $id)->exists()) {
            $base .= '-' . $id;
        }
        return mb_substr($base, 0, $d['slugMax']);
    }

    private function invalid($validator)
    {
        return response()->json([
            'title'  => 'One or more validation errors occurred.',
            'errors' => $validator->errors()->toArray(),
        ], 422);
    }

    private function notFound(array $d)
    {
        return response()->json(['title' => ucfirst($d['noun']) . ' not found.'], 404);
    }
}
