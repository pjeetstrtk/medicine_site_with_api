<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Medicine;
use Illuminate\Http\Request;

class MedicineController extends Controller
{
    public function index(Request $request)
    {
        $validated = $request->validate([
            'q' => ['nullable', 'string', 'max:150'],
            'type' => ['nullable', 'in:allopathic,herbal'],
            'generic_id' => ['nullable', 'integer'],
            'manufacturer_id' => ['nullable', 'integer'],
            'dosage_form_id' => ['nullable', 'integer'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
            'page' => ['nullable', 'integer', 'min:1'],
        ]);

        $query = Medicine::query()->with([
            'generic:generic_id,name,slug,drug_class_id,indication_id',
            'manufacturer:manufacturer_id,name,slug',
            'dosageForm:dosage_form_id,name,slug',
        ]);

        if (!empty($validated['q'])) {
            $term = trim($validated['q']);
            $query->where(function ($q) use ($term) {
                $q->where('brand_name', 'like', "%{$term}%")
                    ->orWhere('slug', 'like', "%{$term}%")
                    ->orWhere('strength', 'like', "%{$term}%")
                    ->orWhere('package_size', 'like', "%{$term}%");
            });
        }

        foreach (['type', 'generic_id', 'manufacturer_id', 'dosage_form_id'] as $field) {
            if (isset($validated[$field])) {
                $query->where($field, $validated[$field]);
            }
        }

        return response()->json($query->orderBy('brand_name')
            ->paginate($validated['per_page'] ?? 20));
    }

    public function show(string $identifier)
    {
        $medicine = Medicine::with([
            'generic.drugClass',
            'generic.indication',
            'manufacturer',
            'dosageForm',
        ])
            ->where('slug', $identifier)
            ->orWhere('brand_id', ctype_digit($identifier) ? (int) $identifier : -1)
            ->firstOrFail();

        return response()->json(['data' => $medicine]);
    }
}
