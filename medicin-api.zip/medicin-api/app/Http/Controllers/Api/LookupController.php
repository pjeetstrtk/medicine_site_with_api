<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Manufacturer;
use App\Models\DosageForm;
use App\Models\Indication;
use App\Models\DrugClass;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Builder;

class LookupController extends Controller
{
    public function manufacturers(Request $request)
    {
        return $this->list($request, Manufacturer::query(), 'name');
    }

    public function dosageForms(Request $request)
    {
        return $this->list($request, DosageForm::query(), 'name');
    }

    public function indications(Request $request)
    {
        return $this->list($request, Indication::query(), 'name');
    }

    public function drugClasses(Request $request)
    {
        return $this->list($request, DrugClass::query(), 'name');
    }

    private function list(Request $request, Builder $query, string $sort)
    {
        $validated = $request->validate([
            'q' => ['nullable', 'string', 'max:150'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
            'page' => ['nullable', 'integer', 'min:1'],
        ]);

        if (!empty($validated['q'])) {
            $term = trim($validated['q']);
            $query->where(function ($q) use ($term) {
                $q->where('name', 'like', "%{$term}%")
                    ->orWhere('slug', 'like', "%{$term}%");
            });
        }

        return response()->json($query->orderBy($sort)
            ->paginate($validated['per_page'] ?? 20));
    }
}
