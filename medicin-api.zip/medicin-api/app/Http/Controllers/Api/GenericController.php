<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Generic;
use Illuminate\Http\Request;

class GenericController extends Controller
{
    public function index(Request $request)
    {
        $validated = $request->validate([
            'q' => ['nullable', 'string', 'max:150'],
            'drug_class_id' => ['nullable', 'integer'],
            'indication_id' => ['nullable', 'integer'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
            'page' => ['nullable', 'integer', 'min:1'],
        ]);

        $query = Generic::query()->with([
            'drugClass:drug_class_id,name,slug',
            'indication:indication_id,name,slug',
        ]);

        if (!empty($validated['q'])) {
            $term = trim($validated['q']);
            $query->where(function ($q) use ($term) {
                $q->where('name', 'like', "%{$term}%")
                    ->orWhere('slug', 'like', "%{$term}%");
            });
        }

        foreach (['drug_class_id', 'indication_id'] as $field) {
            if (isset($validated[$field])) {
                $query->where($field, $validated[$field]);
            }
        }

        return response()->json($query->orderBy('name')
            ->paginate($validated['per_page'] ?? 20));
    }

    public function show(string $identifier)
    {
        $generic = Generic::with([
            'drugClass',
            'indication',
            'medicines.manufacturer',
            'medicines.dosageForm',
        ])
            ->where('slug', $identifier)
            ->orWhere('generic_id', ctype_digit($identifier) ? (int) $identifier : -1)
            ->firstOrFail();

        return response()->json(['data' => $generic]);
    }
}
