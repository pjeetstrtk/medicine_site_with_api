<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DosageForm extends Model
{
    protected $table = 'dosage_forms';
    protected $primaryKey = 'dosage_form_id';
    public $timestamps = false;
    public $incrementing = false;
    protected $keyType = 'int';
    protected $guarded = [];

    public function medicines(): HasMany
    {
        return $this->hasMany(Medicine::class, 'dosage_form_id', 'dosage_form_id');
    }
}
