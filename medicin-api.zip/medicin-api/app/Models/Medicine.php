<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Medicine extends Model
{
    protected $table = 'medicines';
    protected $primaryKey = 'brand_id';
    public $timestamps = false;
    public $incrementing = false;
    protected $keyType = 'int';

    protected $guarded = [];

    public function generic(): BelongsTo
    {
        return $this->belongsTo(Generic::class, 'generic_id', 'generic_id');
    }

    public function manufacturer(): BelongsTo
    {
        return $this->belongsTo(Manufacturer::class, 'manufacturer_id', 'manufacturer_id');
    }

    public function dosageForm(): BelongsTo
    {
        return $this->belongsTo(DosageForm::class, 'dosage_form_id', 'dosage_form_id');
    }
}
