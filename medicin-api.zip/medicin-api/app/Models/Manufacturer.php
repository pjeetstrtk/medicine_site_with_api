<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Manufacturer extends Model
{
    protected $table = 'manufacturers';
    protected $primaryKey = 'manufacturer_id';
    public $timestamps = false;
    public $incrementing = false;
    protected $keyType = 'int';
    protected $guarded = [];

    public function medicines(): HasMany
    {
        return $this->hasMany(Medicine::class, 'manufacturer_id', 'manufacturer_id');
    }
}
