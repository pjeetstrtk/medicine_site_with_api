<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DrugClass extends Model
{
    protected $table = 'drug_classes';
    protected $primaryKey = 'drug_class_id';
    public $timestamps = false;
    public $incrementing = false;
    protected $keyType = 'int';
    protected $guarded = [];

    public function generics(): HasMany
    {
        return $this->hasMany(Generic::class, 'drug_class_id', 'drug_class_id');
    }
}
