<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Indication extends Model
{
    protected $table = 'indications';
    protected $primaryKey = 'indication_id';
    public $timestamps = false;
    public $incrementing = false;
    protected $keyType = 'int';
    protected $guarded = [];

    public function generics(): HasMany
    {
        return $this->hasMany(Generic::class, 'indication_id', 'indication_id');
    }
}
