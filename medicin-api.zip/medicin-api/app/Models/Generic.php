<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Generic extends Model
{
    protected $table = 'generics';
    protected $primaryKey = 'generic_id';
    public $timestamps = false;
    public $incrementing = false;
    protected $keyType = 'int';

    protected $guarded = [];

    public function drugClass(): BelongsTo
    {
        return $this->belongsTo(DrugClass::class, 'drug_class_id', 'drug_class_id');
    }

    public function indication(): BelongsTo
    {
        return $this->belongsTo(Indication::class, 'indication_id', 'indication_id');
    }

    public function medicines(): HasMany
    {
        return $this->hasMany(Medicine::class, 'generic_id', 'generic_id');
    }
}
