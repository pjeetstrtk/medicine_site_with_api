<?php

namespace App\Support;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Describes the six resources once, in the exact JSON shape MedicineWeb expects
 * (camelCase keys, flat names such as genericName / manufacturerName).
 */
class ResourceDefinitions
{
    private const DESCRIPTIONS = [
        'indicationDescription', 'therapeuticClassDescription', 'pharmacologyDescription',
        'dosageDescription', 'administrationDescription', 'interactionDescription',
        'contraindicationsDescription', 'sideEffectsDescription', 'pregnancyLactationDescription',
        'precautionsDescription', 'pediatricUsageDescription', 'overdoseEffectsDescription',
        'durationOfTreatmentDescription', 'reconstitutionDescription', 'storageConditionsDescription',
    ];

    /** URL path => resource key */
    public const PATHS = [
        'medicines'     => 'medicines',
        'generics'      => 'generics',
        'manufacturers' => 'manufacturers',
        'drug-classes'  => 'drugClasses',
        'indications'   => 'indications',
        'dosage-forms'  => 'dosageForms',
    ];

    public static function get(string $key): ?array
    {
        return self::all()[$key] ?? null;
    }

    public static function all(): array
    {
        $descSelect = [];
        $descFields = [];
        foreach (self::DESCRIPTIONS as $key) {
            $col = Str::snake($key);
            $descSelect[] = "g.$col as $key";
            $descFields[$key] = [$col, ['nullable', 'string']];
        }

        return [
            'medicines' => [
                'noun' => 'medicine', 'table' => 'medicines', 'pk' => 'm.brand_id', 'pkCol' => 'brand_id',
                'idKey' => 'brandId', 'nameKey' => 'brandName', 'slugMax' => 120,
                'order' => 'm.brand_name', 'search' => ['m.brand_name'],
                'base' => fn () => DB::table('medicines as m')
                    ->join('dosage_forms as d', 'd.dosage_form_id', '=', 'm.dosage_form_id')
                    ->leftJoin('generics as g', 'g.generic_id', '=', 'm.generic_id')
                    ->join('manufacturers as f', 'f.manufacturer_id', '=', 'm.manufacturer_id'),
                'list' => [
                    'm.brand_id as brandId', 'm.brand_name as brandName', 'm.type', 'm.slug',
                    'm.dosage_form_id as dosageFormId', 'd.name as dosageFormName',
                    'm.generic_id as genericId', 'g.name as genericName', 'm.strength',
                    'm.manufacturer_id as manufacturerId', 'f.name as manufacturerName',
                    'm.package_container as packageContainer', 'm.package_size as packageSize',
                ],
                'detail' => [],
                'filters' => [
                    'type' => 'm.type', 'dosageFormId' => 'm.dosage_form_id',
                    'genericId' => 'm.generic_id', 'manufacturerId' => 'm.manufacturer_id',
                ],
                'unique' => [],
                'dependents' => [],
                'fields' => [
                    'brandName'        => ['brand_name', ['required', 'string', 'max:100']],
                    'type'             => ['type', ['required', 'in:allopathic,herbal']],
                    'slug'             => ['slug', ['nullable', 'string', 'max:120']],
                    'dosageFormId'     => ['dosage_form_id', ['required', 'integer', 'exists:dosage_forms,dosage_form_id']],
                    'genericId'        => ['generic_id', ['nullable', 'integer', 'exists:generics,generic_id']],
                    'strength'         => ['strength', ['nullable', 'string', 'max:100']],
                    'manufacturerId'   => ['manufacturer_id', ['required', 'integer', 'exists:manufacturers,manufacturer_id']],
                    'packageContainer' => ['package_container', ['nullable', 'string', 'max:500']],
                    'packageSize'      => ['package_size', ['nullable', 'string', 'max:200']],
                ],
            ],

            'generics' => [
                'noun' => 'generic', 'table' => 'generics', 'pk' => 'g.generic_id', 'pkCol' => 'generic_id',
                'idKey' => 'id', 'nameKey' => 'name', 'slugMax' => 150,
                'order' => 'g.name', 'search' => ['g.name'],
                'base' => fn () => DB::table('generics as g')
                    ->leftJoin('drug_classes as c', 'c.drug_class_id', '=', 'g.drug_class_id')
                    ->leftJoin('indications as i', 'i.indication_id', '=', 'g.indication_id'),
                'list' => [
                    'g.generic_id as id', 'g.name', 'g.slug', 'g.monograph_link as monographLink',
                    'g.drug_class_id as drugClassId', 'c.name as drugClassName',
                    'g.indication_id as indicationId', 'i.name as indicationName',
                    'g.descriptions_count as descriptionsCount',
                ],
                'detail' => $descSelect,
                'filters' => ['drugClassId' => 'g.drug_class_id', 'indicationId' => 'g.indication_id'],
                'unique' => ['name', 'slug'],
                'dependents' => [],
                'fields' => [
                    'name'              => ['name', ['required', 'string', 'max:150']],
                    'slug'              => ['slug', ['nullable', 'string', 'max:150']],
                    'monographLink'     => ['monograph_link', ['nullable', 'string', 'max:500']],
                    'drugClassId'       => ['drug_class_id', ['nullable', 'integer', 'exists:drug_classes,drug_class_id']],
                    'indicationId'      => ['indication_id', ['nullable', 'integer', 'exists:indications,indication_id']],
                    'descriptionsCount' => ['descriptions_count', ['nullable', 'integer', 'between:0,255']],
                ] + $descFields,
            ],

            'manufacturers' => self::lookup('manufacturer', 'manufacturers', 'manufacturer_id', 100, 120,
                ['genericsCount' => 'generics_count', 'brandNamesCount' => 'brand_names_count'],
                ['name', 'slug'], [['medicines', 'manufacturer_id']]),

            'drugClasses' => self::lookup('drug class', 'drug_classes', 'drug_class_id', 100, 120,
                ['genericsCount' => 'generics_count'], ['slug'], []),

            'indications' => self::lookup('indication', 'indications', 'indication_id', 150, 160,
                ['genericsCount' => 'generics_count'], ['name', 'slug'], []),

            'dosageForms' => self::lookup('dosage form', 'dosage_forms', 'dosage_form_id', 60, 70,
                ['brandNamesCount' => 'brand_names_count'], ['name', 'slug'], [['medicines', 'dosage_form_id']]),
        ];
    }

    private static function lookup(string $noun, string $table, string $pk, int $nameMax, int $slugMax,
                                   array $counts, array $unique, array $dependents): array
    {
        $list = ["t.$pk as id", 't.name', 't.slug'];
        $fields = [
            'name' => ['name', ['required', 'string', "max:$nameMax"]],
            'slug' => ['slug', ['nullable', 'string', "max:$slugMax"]],
        ];
        foreach ($counts as $key => $col) {
            $list[] = "t.$col as $key";
            $fields[$key] = [$col, ['nullable', 'integer', 'min:0']];
        }

        return [
            'noun' => $noun, 'table' => $table, 'pk' => "t.$pk", 'pkCol' => $pk,
            'idKey' => 'id', 'nameKey' => 'name', 'slugMax' => $slugMax,
            'order' => 't.name', 'search' => ['t.name'],
            'base' => fn () => DB::table("$table as t"),
            'list' => $list, 'detail' => [], 'filters' => [],
            'unique' => $unique, 'dependents' => $dependents, 'fields' => $fields,
        ];
    }
}
